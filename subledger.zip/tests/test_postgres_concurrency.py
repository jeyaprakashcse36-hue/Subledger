import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import HTTPException
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker

from app.db.session import Base
from app.models import (
    Customer,
    Invoice,
    LedgerEntry,
    PaymentAttempt,
    Plan,
    Subscription,
)
from app.schemas.payment import PaymentCreate
from app.services.payment_service import PaymentService


TEST_DATABASE_URL = os.getenv("TEST_DATABASE_URL")
pytestmark = pytest.mark.skipif(
    not TEST_DATABASE_URL,
    reason="Set TEST_DATABASE_URL to run PostgreSQL concurrency coverage",
)


def test_concurrent_payments_cannot_overpay_postgres():
    if not TEST_DATABASE_URL:
        pytest.skip("Set TEST_DATABASE_URL to run PostgreSQL concurrency coverage")
    database_name = TEST_DATABASE_URL.rsplit("/", 1)[-1].split("?", 1)[0]
    if not database_name.endswith("_test"):
        pytest.fail("TEST_DATABASE_URL must point to a dedicated database ending in _test")

    engine = create_engine(TEST_DATABASE_URL, pool_pre_ping=True)
    Base.metadata.create_all(engine)
    test_sessions = sessionmaker(bind=engine, expire_on_commit=False)
    marker = uuid4().hex

    try:
        with test_sessions() as session:
            customer = Customer(name="Concurrency Test", email=f"{marker}@example.test")
            plan = Plan(
                name=f"Concurrency-{marker[:8]}",
                price=Decimal("100.00"),
                currency="INR",
                billing_interval="monthly",
                is_active=True,
            )
            session.add_all((customer, plan))
            session.flush()
            now = datetime.now(timezone.utc)
            subscription = Subscription(
                customer_id=customer.id,
                plan_id=plan.id,
                status="active",
                current_period_start=now,
                current_period_end=now.replace(year=now.year + 1),
            )
            session.add(subscription)
            session.flush()
            invoice = Invoice(
                subscription_id=subscription.id,
                customer_id=customer.id,
                amount_due=Decimal("100.00"),
                amount_paid=Decimal("0.00"),
                currency="INR",
                status="issued",
                period_start=now,
                period_end=now.replace(year=now.year + 1),
            )
            session.add(invoice)
            session.commit()
            invoice_id = invoice.id

        def attempt(key: str) -> str:
            with test_sessions() as session:
                try:
                    PaymentService(session).create_payment(
                        PaymentCreate(
                            invoice_id=invoice_id,
                            amount=Decimal("60.00"),
                            currency="INR",
                            status="succeeded",
                            idempotency_key=key,
                        )
                    )
                    return "succeeded"
                except HTTPException as error:
                    return f"rejected:{error.status_code}"

        with ThreadPoolExecutor(max_workers=2) as executor:
            outcomes = list(
                executor.map(
                    attempt,
                    (f"{marker}-first", f"{marker}-second"),
                )
            )

        assert sorted(outcomes) == ["rejected:422", "succeeded"]
        with test_sessions() as session:
            saved_invoice = session.get(Invoice, invoice_id)
            assert saved_invoice is not None
            assert saved_invoice.amount_paid == Decimal("60.00")
            assert (
                session.scalar(
                    select(func.count(PaymentAttempt.id)).where(
                        PaymentAttempt.invoice_id == invoice_id
                    )
                )
                == 1
            )
            assert (
                session.scalar(
                    select(func.count(LedgerEntry.id)).where(
                        LedgerEntry.invoice_id == invoice_id
                    )
                )
                == 1
            )
    finally:
        engine.dispose()
