import os
from uuid import uuid4

import pytest
from sqlalchemy import create_engine, insert, text
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DBAPIError

from app.models import Customer, LedgerEntry


TEST_DATABASE_URL = os.getenv("TEST_DATABASE_URL")


@pytest.fixture
def postgres_test_engine():
    if not TEST_DATABASE_URL:
        pytest.skip("Set TEST_DATABASE_URL to run PostgreSQL integration coverage")

    database_url = make_url(TEST_DATABASE_URL)
    if database_url.get_backend_name() != "postgresql":
        pytest.fail("TEST_DATABASE_URL must use PostgreSQL")
    if not database_url.database or not database_url.database.endswith("_test"):
        pytest.fail("TEST_DATABASE_URL must point to a dedicated database ending in _test")

    engine = create_engine(TEST_DATABASE_URL, pool_pre_ping=True)
    try:
        yield engine
    finally:
        engine.dispose()


def test_ledger_entries_reject_direct_update_and_delete_postgres(
    postgres_test_engine,
):
    marker = uuid4().hex
    with postgres_test_engine.connect() as connection:
        transaction = connection.begin()
        try:
            customer_id = connection.execute(
                insert(Customer)
                .values(name="Append-only test", email=f"{marker}@example.test")
                .returning(Customer.id)
            ).scalar_one()
            entry_id = connection.execute(
                insert(LedgerEntry)
                .values(
                    customer_id=customer_id,
                    entry_type="test",
                    amount="1.00",
                    currency="INR",
                    reference_id=marker,
                )
                .returning(LedgerEntry.id)
            ).scalar_one()

            statements = (
                text("UPDATE ledger_entries SET amount = 2.00 WHERE id = :id"),
                text("DELETE FROM ledger_entries WHERE id = :id"),
            )
            for statement in statements:
                savepoint = connection.begin_nested()
                try:
                    with pytest.raises(DBAPIError) as error:
                        connection.execute(statement, {"id": entry_id})
                    assert "ledger entries are append-only" in str(
                        error.value.orig
                    ).lower()
                finally:
                    if savepoint.is_active:
                        savepoint.rollback()
        finally:
            transaction.rollback()
