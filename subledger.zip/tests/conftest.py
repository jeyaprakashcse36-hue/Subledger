from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import event
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool
from sqlalchemy import create_engine

from app.db.session import Base, get_db
from app.main import app
from app import models as _models  # noqa: F401


@pytest.fixture
def test_engine():
    engine = create_engine(
        "sqlite+pysqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )

    @event.listens_for(engine, "connect")
    def enable_foreign_keys(dbapi_connection, connection_record) -> None:
        dbapi_connection.isolation_level = None
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    @event.listens_for(engine, "begin")
    def begin_sqlite_transaction(connection) -> None:
        connection.exec_driver_sql("BEGIN")

    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def db_session(test_engine) -> Iterator[Session]:
    testing_session = sessionmaker(
        bind=test_engine, autoflush=False, expire_on_commit=False
    )
    with testing_session() as session:
        yield session


@pytest.fixture
def client(test_engine) -> Iterator[TestClient]:
    testing_session = sessionmaker(
        bind=test_engine, autoflush=False, expire_on_commit=False
    )

    def override_get_db():
        with testing_session() as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture
def customer(client: TestClient) -> dict:
    response = client.post(
        "/api/v1/customers",
        json={"name": "Ada Lovelace", "email": "Ada@example.com"},
    )
    assert response.status_code == 201
    return response.json()


@pytest.fixture
def plan(client: TestClient) -> dict:
    response = client.post(
        "/api/v1/plans",
        json={
            "name": "Standard",
            "price": "100.00",
            "currency": "INR",
            "billing_interval": "monthly",
        },
    )
    assert response.status_code == 201
    return response.json()


@pytest.fixture
def subscription(client: TestClient, customer: dict, plan: dict) -> dict:
    response = client.post(
        "/api/v1/subscriptions",
        json={
            "customer_id": customer["id"],
            "plan_id": plan["id"],
            "current_period_start": "2026-01-01T00:00:00Z",
            "current_period_end": "2026-02-01T00:00:00Z",
        },
    )
    assert response.status_code == 201
    return response.json()


@pytest.fixture
def invoice(client: TestClient, subscription: dict) -> dict:
    response = client.post(
        "/api/v1/invoices",
        json={
            "subscription_id": subscription["id"],
            "period_start": "2026-01-01",
            "period_end": "2026-02-01",
        },
    )
    assert response.status_code == 201
    return response.json()
